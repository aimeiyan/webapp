{
    "appDir": "../www",
    "baseUrl": "lib",
    "paths": {
        "app": "../app"
    },
    "dir": "../www-built",
    "modules": [
        {
            "name": "app"
        }
    ]
}

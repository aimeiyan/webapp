<?php

class Text_Wiki_Render_Latex_Freelink extends Text_Wiki_Render_Latex_Wikilink {
    // renders identically to wikilinks, only the parsing is different :-)    
}
?>

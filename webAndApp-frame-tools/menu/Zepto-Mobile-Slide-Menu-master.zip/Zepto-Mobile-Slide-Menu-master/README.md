Zepto.js - Slide Menu Example
==============================================

DEMO: http://www.tegdesign.com/Zepto-Mobile-Slide-Menu/

Note: To demo it in a web browser you need turn on "Emulate touch events" in the Goolge Chrome developer tools settings.

This is a hardware accelerated slide menu example. I modeled it after Facebook's famous menu.

Here is the JQuery Mobile version: https://github.com/tegansnyder/JQuery-Mobile-Slide-Menu


Note:
==============================================
Menu would work best in a Phonegap application with the device orientation locked to Portrait.


Credits:
==============================================
Zepto - https://github.com/madrobby/zepto/graphs/contributors
JQuery Touchwipe - Andreas Waltl [* I modified it to work with Zepto *]
